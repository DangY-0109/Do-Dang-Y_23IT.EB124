package Thi;

public interface Employee_interface {
		public void HienThi();
}
